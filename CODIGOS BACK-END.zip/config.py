# config.py
plataforma_de_gestion_de_eventos = {
    'host': 'linux-vm7',
    'port': 3306,
    'user': 'acajigas9496',
    'password': 'r00509496',
    'database': 'plataforma_de_gestion_de_eventos'
}
