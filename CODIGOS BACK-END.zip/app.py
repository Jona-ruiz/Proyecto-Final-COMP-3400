from flask import Flask, jsonify, request
import mariadb
import sys

# Importa la configuración de acceso a la base de datos 
from config import plataforma_de_gestion_de_eventos
app = Flask(__name__)

try:
    conn = mariadb.connect(**plataforma_de_gestion_de_eventos)
except mariadb.Error as e:
    print(f"Error con conexion: {e}")
    sys.exit(1)

cursor = conn.cursor()

# Ruta de prueba
@app.route('/api/hello', methods=['GET'])
def hello_world():
    return jsonify({'message': '¡Hola, mundo con Flask!'})

# Ruta para obtener información sobre el usuario
@app.route('/api/misdatos/', methods=['GET'])
def mis_datos():
    # Aquí puedes devolver información específica sobre el usuario, como su nombre, teléfono, etc.
    return jsonify({'datos': 'Juan Perez, 879901010, juanperez@gmail.com, Calle 123'})

# Ruta para obtener todos los usuarios Y eventos
@app.route('/api/get_users', methods=['GET'])
def get_users():
    cursor.execute("SELECT * FROM Usuarios")
    users = cursor.fetchall()
    user_list = []
    for user in users:
        user_list.append({
            "id_usuarios": user[0],
            "nombre": user[1],
            "telefono": user[2],
            "email": user[3],
            "direccion_fisica": user[4]
        })

    response = jsonify({"data": user_list})
    response.headers.add("Content-type", 'application/json')
    response.headers.add('Access-Control-Allow-Origin', '*')
    return response

# Ruta para obtener todos los eventos
@app.route('/api/get_eventos', methods=['GET'])
def get_eventos():
    cursor.execute("SELECT * FROM Eventos")
    eventos = cursor.fetchall()
    eventos_list = []
    for evento in eventos:
        eventos_list.append({
            "id_evento": evento[0],
            "fecha_registro": evento[1],
            "fecha_evento": evento[2],
            "lugar": evento[3],
            "tipo": evento[4],
            "descripcion": evento[5]
        })

    response = jsonify({"data": eventos_list})
    response.headers.add("Content-type", 'application/json')
    response.headers.add('Access-Control-Allow-Origin', '*')
    return response

# Ruta para obtener toda la data de usuarios y eventos
@app.route('/api/get_inscripciones', methods=['GET'])
def get_inscripciones():
    cursor.execute("SELECT * FROM v_all_tables")
    inscripciones = cursor.fetchall()
    inscripciones_list = []
    for inscripcione in inscripciones:
        inscripciones_list.append({
            "id_usuarios": inscripcione[0],
            "nombre": inscripcione[1],
            "telefono": inscripcione[2],
            "email": inscripcione[3],
            "direccion_fisica": inscripcione[4],
            "id_evento": inscripcione[5],
            "fecha_registro": inscripcione[6],
            "fecha_evento": inscripcione[7],
            "lugar": inscripcione[8],
            "tipo": inscripcione[9],
            "descripcion": inscripcione[10]
        })

    response = jsonify({"data": inscripciones_list})
    response.headers.add("Content-type", 'application/json')
    response.headers.add('Access-Control-Allow-Origin', '*')
    return response

# Ruta para obtener un usuario por su ID
@app.route('/api/get_user/<int:id>', methods=['GET'])
def get_user(id):
    if id == 0:
        return jsonify({"error": "ID inválido"}), 404
    else:
        cursor.execute("SELECT * FROM usuarios WHERE ID_registro = ?", (id,))
        user = cursor.fetchone()
        if user:
            user_data = {
                "ID_registro": user[0],
                "nombre": user[1],
                "telefono": user[2],
                "correo_electronico": user[3],
                "direccion_fisica": user[4],
                "ID_evento": user[5],
                "tipo_de_evento": user[6],
                "descripcion_de_evento": user[7],
                "lugar_de_evento": user[8],
                "fecha_de_evento": user[9],
                "fecha_de_registro": user[10]
            }
            return jsonify(user_data)
        else:
            return jsonify({"message": "Usuario no encontrado"}), 404

# Ruta para obtener un evento por su ID
@app.route('/api/get_event/<int:id>', methods=['GET'])
def get_event(id):
    if id == 0:
        return jsonify({"error": "ID inválido"}), 404
    else:
        cursor.execute("SELECT * FROM Eventos WHERE ID_evento = ?", (id,))
        evento = cursor.fetchone()
        if evento:
            evento_data = {
                "ID_evento": evento[0],
                "fecha_registro": evento[1],
                "fecha_evento": evento[2],
                "lugar": evento[3],
                "tipo": evento[4],
                "descripcion": evento[5]
            }
            return jsonify(evento_data)
        else:
            return jsonify({"message": "Evento no encontrado"}), 404

# Ruta para agregar un nuevo usuario y evento
@app.route('/api/new_user', methods=['POST'])
def new_user():
    datos = request.json
    nombre = datos.get('nombre')
    telefono = datos.get('telefono')
    correo_electronico = datos.get('correo_electronico')
    direccion_fisica = datos.get('direccion_fisica')
    ID_evento = datos.get('ID_evento')
    tipo_de_evento = datos.get('tipo_de_evento')
    descripcion_de_evento = datos.get('descripcion_de_evento')
    lugar_de_evento = datos.get('lugar_de_evento')
    fecha_de_evento = datos.get('fecha_de_evento')
    fecha_de_registro = datos.get('fecha_de_registro')

    strQry = 'INSERT INTO usuarios '
    strQry += "(nombre, telefono, correo_electronico, direccion_fisica, ID_evento, tipo_de_evento, descripcion_de_evento, lugar_de_evento, fecha_de_evento, fecha_de_registro) "
    strQry += f"VALUES ('{nombre}', '{telefono}', '{correo_electronico}', '{direccion_fisica}', '{ID_evento}', '{tipo_de_evento}', '{descripcion_de_evento}', '{lugar_de_evento}', '{fecha_de_evento}', '{fecha_de_registro}')"

    cursor.execute(strQry)
    conn.commit()

    response = {"message": "Registro insertado exitosamente"}
    
    return jsonify(response), 200

# Ruta para actualizar usuario
@app.route('/api/update_user', methods=['PUT'])
def update_user():
    datos = request.json
    ID_registro = datos.get('ID_registro')
    nombre = datos.get('nombre')
    telefono = datos.get('telefono')
    correo_electronico = datos.get('correo_electronico')
    direccion_fisica = datos.get('direccion_fisica')
    
    strQry = 'UPDATE usuarios '
    strQry += f"SET nombre = '{nombre}', "
    strQry += f"telefono = '{telefono}', "
    strQry += f"correo_electronico = '{correo_electronico}', "
    strQry += f"direccion_fisica = '{direccion_fisica}' "
    strQry += f"WHERE ID_registro = {ID_registro}"

    cursor.execute(strQry)
    conn.commit()

    response = {"message": "Registro de usuario actualizado exitosamente"}
    
    return jsonify(response), 200

# Ruta para actualizar evento
@app.route('/api/update_event', methods=['PUT'])
def update_event():
    datos = request.json
    ID_evento = datos.get('ID_evento')
    fecha_evento = datos.get('fecha_evento')
    lugar = datos.get('lugar')
    tipo = datos.get('tipo')
    descripcion = datos.get('descripcion')
    fecha_registro = datos.get('fecha_registro')

    strQry = 'UPDATE Eventos '
    strQry += f"SET fecha_evento = '{fecha_evento}', "
    strQry += f"lugar = '{lugar}', "
    strQry += f"tipo = '{tipo}', "
    strQry += f"descripcion = '{descripcion}', "
    strQry += f"fecha_registro = '{fecha_registro}' "
    strQry += f"WHERE ID_evento = {ID_evento}"

    cursor.execute(strQry)
    conn.commit()

    response = {"message": "Registro de evento actualizado exitosamente"}
    
    return jsonify(response), 200

# Ruta para eliminar un usuario por su ID
@app.route('/api/del_user/<int:id>', methods=['DELETE'])
def del_user(id):
    if id == 0:
        return jsonify({"error": "ID inválido"}), 404
    else:
        cursor.execute("DELETE FROM usuarios WHERE ID_registro = ?", (id,))
        conn.commit()
        return jsonify({"message": "Usuario eliminado correctamente"}), 200

# Ruta para eliminar un evento por su ID
@app.route('/api/del_event/<int:id>', methods=['DELETE'])
def del_event(id):
    if id == 0:
        return jsonify({"error": "ID inválido"}), 404
    else:
        cursor.execute("DELETE FROM Eventos WHERE ID_evento = ?", (id,))
        conn.commit()
        return jsonify({"message": "Evento eliminado correctamente"}), 200

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
